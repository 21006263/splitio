let e="";function a(s){e=s.base,s.assets}export{e as b,a as s};
