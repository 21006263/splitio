const timestamp = 1699035346295;
const build = [
  "/_app/start-11c51c61.js",
  "/_app/assets/start-61d1577b.css",
  "/_app/layout.svelte-18bbdb35.js",
  "/_app/pages/__error.svelte-3fb10913.js",
  "/_app/assets/pages/__error.svelte-57db0ec6.css",
  "/_app/pages/index.svelte-d2499211.js",
  "/_app/assets/pages/index.svelte-0743d7a3.css",
  "/_app/pages/inspector/__layout.svelte-e67c6521.js",
  "/_app/assets/pages/g/__layout.svelte-51b199f7.css",
  "/_app/pages/inspector/index.svelte-ad518ae2.js",
  "/_app/pages/inspector/[groupid].svelte-165346c4.js",
  "/_app/pages/about.svelte-c1bc37f0.js",
  "/_app/assets/pages/about.svelte-d9c79cf3.css",
  "/_app/pages/error.svelte-697c2df9.js",
  "/_app/pages/g/__layout.svelte-d439f8e0.js",
  "/_app/pages/g/index.svelte-2f28c151.js",
  "/_app/pages/g/[groupid].svelte-10945803.js",
  "/_app/assets/pages/g/[groupid].svelte-334d98a1.css",
  "/_app/chunks/vendor-6107b1a1.js",
  "/_app/chunks/singletons-12a22614.js",
  "/_app/chunks/paths-28a87002.js",
  "/_app/chunks/SplitioIcon-ff3fb2b7.js",
  "/_app/assets/SplitioIcon-84dd6a9f.css",
  "/_app/chunks/navigation-51f4a605.js",
  "/_app/chunks/secure-318f4c02.js",
  "/_app/chunks/recentGroupsStorage-f38fd934.js",
  "/_app/assets/recentGroupsStorage-3f1ccb45.css",
  "/_app/chunks/stores-7a9bd7b0.js"
];
const files = [
  "/favicon.png",
  "/logo_192.png",
  "/logo_512.png",
  "/logo_black.png",
  "/smui-dark.css",
  "/smui.css",
  "/splitio_banner.png",
  "/_manifest.json"
];
const worker = self;
const FILES = `cache${timestamp}`;
const to_cache = build.concat(files);
const staticAssets = new Set(to_cache);
worker.addEventListener("install", (event) => {
  event.waitUntil(caches.open(FILES).then((cache) => cache.addAll(to_cache)).then(() => {
    worker.skipWaiting();
  }));
});
worker.addEventListener("activate", (event) => {
  event.waitUntil(caches.keys().then(async (keys) => {
    for (const key of keys) {
      if (key !== FILES)
        await caches.delete(key);
    }
    worker.clients.claim();
  }));
});
async function fetchAndCache(request) {
  const cache = await caches.open(`offline${timestamp}`);
  try {
    const response = await fetch(request);
    cache.put(request, response.clone());
    return response;
  } catch (err) {
    const response = await cache.match(request);
    if (response)
      return response;
    throw err;
  }
}
worker.addEventListener("fetch", (event) => {
  if (event.request.method !== "GET" || event.request.headers.has("range"))
    return;
  const url = new URL(event.request.url);
  const isHttp = url.protocol.startsWith("http");
  const isDevServerRequest = url.hostname === self.location.hostname && url.port !== self.location.port;
  const isStaticAsset = url.host === self.location.host && staticAssets.has(url.pathname);
  const skipBecauseUncached = event.request.cache === "only-if-cached" && !isStaticAsset;
  if (isHttp && !isDevServerRequest && !skipBecauseUncached) {
    event.respondWith((async () => {
      const cachedAsset = isStaticAsset && await caches.match(event.request);
      return cachedAsset || fetchAndCache(event.request);
    })());
  }
});
