enum GroupNodeStates {
    Found = "FOUND",
    Unknown = "UNKNOWN",
    NotFound = "NotFound",
    Error = "ERROR",
};

export {
    GroupNodeStates
};
