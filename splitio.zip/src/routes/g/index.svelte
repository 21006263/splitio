<script context="module">
	export async function load() {
	  return {
		status: 301,
		redirect: `/`,
	  }
	}
  </script>

<svelte:head>
	<title>splitio | redirecting...</title>
</svelte:head>
